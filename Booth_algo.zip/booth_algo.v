`timescale 1ns/1ps

module booth_multiplier #(
    parameter N = 4
)(
    input  wire               clk,
    input  wire               rst,
    input  wire               start,
    input  wire [N-1:0]       multiplicand,
    input  wire [N-1:0]       multiplier,
    output wire [2*N-1:0]     product,
    output reg                done,

    output reg  [N:0]         acc,
    output reg  [N-1:0]       q,
    output reg                q_1,
    output reg  [7:0]         count
);

    localparam [2:0] S_IDLE  = 3'd0,
                     S_CHECK = 3'd1,
                     S_SHIFT = 3'd2,
                     S_TEST  = 3'd3,
                     S_STOP  = 3'd4;

    reg [N-1:0] m;
    reg [2:0]   state;

    wire [N:0]  m_ext = {m[N-1], m};

    wire do_add = (~q[0]) &   q_1;
    wire do_sub =   q[0]  & (~q_1);

    assign product = {acc[N-1:0], q};

    always @(posedge clk) begin
        if (rst) begin
            state <= S_IDLE;
            acc   <= 0;
            q     <= 0;
            q_1   <= 1'b0;
            m     <= 0;
            count <= 0;
            done  <= 1'b0;
        end else begin
            case (state)

                S_IDLE: begin
                    if (start) begin
                        acc   <= 0;
                        q_1   <= 1'b0;
                        m     <= multiplicand;
                        q     <= multiplier;
                        count <= N;
                        done  <= 1'b0;
                        state <= S_CHECK;
                    end
                end

                S_CHECK: begin
                    if (do_add)
                        acc <= acc + m_ext;
                    else if (do_sub)
                        acc <= acc - m_ext;
                    state <= S_SHIFT;
                end

                S_SHIFT: begin
                    acc   <= {acc[N], acc[N:1]};
                    q     <= {acc[0], q[N-1:1]};
                    q_1   <= q[0];
                    count <= count - 1'b1;
                    state <= S_TEST;
                end

                S_TEST: begin
                    if (count == 8'd0)
                        state <= S_STOP;
                    else
                        state <= S_CHECK;
                end

                S_STOP: begin
                    done  <= 1'b1;
                    state <= S_IDLE;
                end

                default: state <= S_IDLE;
            endcase
        end
    end

endmodule
`timescale 1ns/1ps

module booth_tb;

    parameter N = 4;

    reg                      clk;
    reg                      rst;
    reg                      start;
    reg  [N-1:0]             multiplicand;
    reg  [N-1:0]             multiplier;
    wire signed [2*N-1:0]    product;
    wire                     done;

    wire [N:0]               acc;
    wire [N-1:0]             q;
    wire                     q_1;
    wire [7:0]               count;

    reg                      trace_en;
    integer                  i, j, errors, tests;
    reg signed [2*N-1:0]     expected;

    booth_multiplier #(.N(N)) dut (
        .clk          (clk),
        .rst          (rst),
        .start        (start),
        .multiplicand (multiplicand),
        .multiplier   (multiplier),
        .product      (product),
        .done         (done),
        .acc          (acc),
        .q            (q),
        .q_1          (q_1),
        .count        (count)
    );

    initial clk = 1'b0;
    always #5 clk = ~clk;

    reg [N:0]   acc_op;
    reg [1:0]   qq;
    reg [39:0]  op_name;
    integer     iter;

    always @(posedge clk) begin
        if (trace_en) begin
            case (dut.state)
                3'd1: begin
                    if (count == N) begin
                        iter = 0;
                        $display("  Init   : Acc=%b  Q=%b  Q-1=%b  M=%b  Count=%0d",
                                 acc, q, q_1, dut.m, count);
                    end
                    qq = {q[0], q_1};
                    case (qq)
                        2'b01:   op_name = "Acc+M";
                        2'b10:   op_name = "Acc-M";
                        default: op_name = "none ";
                    endcase
                end
                3'd2: acc_op = acc;
                3'd3: begin
                    iter = iter + 1;
                    $display("  Iter %0d : Q0Q-1=%b  %s  Acc=%b | shift -> Acc=%b  Q=%b  Q-1=%b  Count=%0d",
                             iter, qq, op_name, acc_op, acc, q, q_1, count);
                end
                default: ;
            endcase
        end
    end

    task run_booth;
        input [N-1:0] a;
        input [N-1:0] b;
        begin
            multiplicand = a;
            multiplier   = b;
            @(negedge clk);
            start = 1'b1;
            @(negedge clk);
            start = 1'b0;
            @(posedge done);
            @(negedge clk);
        end
    endtask

    initial begin
        $dumpfile("booth.vcd");
        $dumpvars(0, booth_tb);

        rst = 1'b1;  start = 1'b0;
        multiplicand = 0;  multiplier = 0;
        trace_en = 1'b0;
        errors = 0;  tests = 0;

        repeat (3) @(negedge clk);
        rst = 1'b0;
        @(negedge clk);

        $display("=== Demo 1: (-3) x 5 ===");
        trace_en = 1'b1;
        run_booth(-3, 5);
        trace_en = 1'b0;
        $display("  Final  : Acc=%b  Q=%b  Q-1=%b  Count=%0d", acc, q, q_1, count);
        $display("  product = %0d  (expected -15)\n", product);

        $display("=== Demo 2: 7 x 3 ===");
        trace_en = 1'b1;
        run_booth(7, 3);
        trace_en = 1'b0;
        $display("  Final  : Acc=%b  Q=%b  Q-1=%b  Count=%0d", acc, q, q_1, count);
        $display("  product = %0d  (expected 21)\n", product);

        $display("=== Exhaustive test, N = %0d ===", N);
        for (i = -(1 << (N-1)); i < (1 << (N-1)); i = i + 1) begin
            for (j = -(1 << (N-1)); j < (1 << (N-1)); j = j + 1) begin
                run_booth(i, j);
                expected = i * j;
                tests = tests + 1;
                if (product !== expected) begin
                    errors = errors + 1;
                    $display("  FAIL: %0d x %0d = %0d, expected %0d", i, j, product, expected);
                end
            end
        end

        if (errors == 0)
            $display("PASS: all %0d combinations correct", tests);
        else
            $display("FAILED: %0d errors out of %0d tests", errors, tests);

        $finish;
    end

    initial begin
        #100000000;
        $display("TIMEOUT");
        $finish;
    end

endmodule